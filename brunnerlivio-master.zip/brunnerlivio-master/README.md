<!-- "Hero" Header -->
<div align="center">
  <img src="https://github.com/BrunnerLivio/brunnerlivio/blob/master/images/welcome.png?raw=true" style="max-width: 100%;" alt="Welcome to my Github Profile" />
  <br />
  <br />
  <img height="50" alt="My Name is Livio and I like Node.js" src="images/personal_note.svg" />
  <br />
  <br />

</div>

<!-- Social -->
<table width="100%" align="center">
<tr>
<td align="center">
<a href="https://brunnerliv.io">
<strong>Visit my personal website </strong>
<br />
<br />
<br />

<p>

<img alt="Globe" height="80" src="images/globe.gif">
</a>
</p>

</td>


<td align="center">
<a href="https://www.youtube.com/watch?v=3YxaaGgTQYM&ab_channel=EvanescenceVEVO">
<strong>Listen to cool music</strong>
<br />
<br />


<p>
<img height="100" alt="Music" src="images/music.gif"> 
</a>
</p>

</td>
</tr>
</table>

<div align="center">
<a href="https://github.com/BrunnerLivio/brunnerlivio/issues/62#issuecomment-new"><img src="images/guestbook.svg"></a> 
</div>

<!-- Guestbook -->
| Name | Date | Message |
|---|---|---|
| <a href="https://github.com/angelamcosta"><img width="24" src="https://avatars.githubusercontent.com/u/14792447?s=24&u=331aef502a77bc55233c30333368980e4babf819&v=4" alt="angelamcosta" /> angelamcosta</a> |7/14/2025, 3:44:10 PM|はじめまして、ブラジル人です ❥|
| <a href="https://github.com/Radajaaj"><img width="24" src="https://avatars.githubusercontent.com/u/64104035?s=24&u=f4bd56a1d9c4ae1d42f6bccf5ba62d265f1ad83f&v=4" alt="Radajaaj" /> Radajaaj</a> |7/11/2025, 9:58:24 PM|🍍|
| <a href="https://github.com/sainath-666"><img width="24" src="https://avatars.githubusercontent.com/u/96917328?s=24&u=1d02b47b8b6d46ed543591404e84664e1116cd9e&v=4" alt="sainath-666" /> sainath-666</a> |7/8/2025, 4:45:44 PM|Hi, I am a WEB DEVELOPER|
| <a href="https://github.com/Quimisagi"><img width="24" src="https://avatars.githubusercontent.com/u/26472514?s=24&u=f88c9f0ad1b5b8251f77ea34b151d6b7e10fcf28&v=4" alt="Quimisagi" /> Quimisagi</a> |6/26/2025, 6:23:38 AM|Hello from Japan|
| <a href="https://github.com/nahtanpng"><img width="24" src="https://avatars.githubusercontent.com/u/93049899?s=24&u=8d862c24f64c128c215718ef1df759ebf4145c6b&v=4" alt="nahtanpng" /> nahtanpng</a> |6/25/2025, 10:04:12 PM|Hello from São Paulo! 👋|
<!-- /Guestbook -->

<!-- Footer -->

<div align="center">

<img height="120" alt="Thanks for visiting me" width="100%" src="https://raw.githubusercontent.com/BrunnerLivio/brunnerlivio/master/images/marquee.svg" />
<br />

![Visitor Count](https://profile-counter.glitch.me/brunnerlivio/count.svg)


<img src="https://raw.githubusercontent.com/BrunnerLivio/brunnerlivio/master/images/notepad.gif" alt="Site created with Notepad" height="30" />
<!-- "margin-right: whatever;" -->
<span>&nbsp;&nbsp;&nbsp;&nbsp;</span>  
<img src="https://raw.githubusercontent.com/BrunnerLivio/brunnerlivio/master/images/ie_logo.gif" alt="Microsoft Internet Explorer" />
<span>&nbsp;&nbsp;&nbsp;&nbsp;</span>  
<img src="https://raw.githubusercontent.com/BrunnerLivio/brunnerlivio/master/images/noframes.gif" alt="Microsoft Internet Explorer" />

</div>
